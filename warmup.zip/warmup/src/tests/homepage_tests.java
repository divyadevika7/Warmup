package tests;

public class homepage_tests {
    @FindBy(id = ("#myTopnav > div.emt_nav > ul > li:nth-child(2) > a"))
    private WebElement Hotelslink;



    public void clickOnHotelslink;(){
        waits.waitForElementToBeVisible(Hotelslink, "wait for new Hotelslink to be visible and click on it", 10).click();
    }

    public boolean isHotelslinkDisplayed() {
        return waits.waitForElementToBeVisible(Hotelslink, "wait for Hotelslink to be visible", 10)
                .isDisplayed();
    }

}
